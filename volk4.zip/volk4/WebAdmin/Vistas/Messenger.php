
<h2 class="Estilo1"><font face="Tahoma" size="3" color="#666666">Messenger Stealers</font></h2>


<div id="table_estadisticas" name="table_estadisticas" >

<?php require_once('../Controladores/Messenger.php'); ?>
</div>


<div id='mensajebot' name='mensajebot' align='center' style="color:#FF0000"></div>