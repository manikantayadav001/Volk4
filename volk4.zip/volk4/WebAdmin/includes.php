<?php
require_once('Class/class.base.de.datos.php');
require_once('Class/PHPPaging.lib.php');
require_once('Configs/Configs.php');
?>